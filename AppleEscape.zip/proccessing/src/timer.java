import processing.core.PApplet;

public class timer {

    public static int count = -1;
    PApplet p;
    float t1;

    public timer(float t, PApplet p){
        this.p = p;
        t1 = t;
        count ++;
    }

    public boolean go(float time){
        return p.millis() - t1 >= time*1000;
    }
}
