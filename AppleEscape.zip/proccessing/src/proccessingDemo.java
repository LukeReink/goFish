import processing.core.PApplet;
import processing.core.PMatrix3D;
import processing.core.PMatrix;
import java.awt.*;

public class proccessingDemo extends PApplet{
    public static void main(String [] args){
        PApplet.main("proccessingDemo");
    }

    //window size gets set in settings()
    public void settings(){
        size(600, 600, P3D);
    }
    int x;
    int y;
    public void setup() {
        x = 100;
        y = 100;
    }
    int xspeed = 2;
    int yspeed = 3;
    int c = color(0);
    float theta = 0;

    public void draw(){
        background(255);
        rectMode(CENTER);
//        x+= xspeed;
//        y+= yspeed;
//        fill(c);
//        rect(x,y,40,40);
//        if(x >= width- 20){
//            x = width - 21;
//            xspeed *= -1;
//        }
//        if(x <= 20){
//            x = 21;
//            xspeed *= -1;
//        }
//        if(y >= height-20){
//            y = height-21;
//            yspeed *= -1;
//        }
//        if(y <= 20){
//            yspeed *= -1;
//            y = 21;
//        }
//        if(mouseX >= x - 20 && mouseX <= x + 20 && mouseY >= y - 20 && mouseY <= y + 20){
//            c = color(255,0,0);
//        }
//        else
//            c = color(0);
        translate(width/2,height/2);
        theta = map(mouseX, 0, width, 0, TWO_PI);
        rotateX(theta);
        rotateY(theta);
    }

    public void drawTriangle(float t){
        beginShape(TRIANGLES);
        fill(120,12,12,30);
        vertex(-t,-t,-t);
        vertex(t,-t,-t);
        vertex(0,0,0);
        fill(21,43,12,24);
        vertex(t,-t,-t);
        vertex(t,t,-t);
        vertex(0,0,0);
        fill(21,1,42,21);
        vertex(t,t,-t);
        vertex(-t,t,-t);
        vertex(0,0,0);
        fill(10,240,2,12);
        vertex(-t,t,-t);
        vertex(-t,-t,-t);
        vertex(0,0,0);
        endShape(CLOSE);
    }

}
